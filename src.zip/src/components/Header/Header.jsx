import React from "react";
import "./Header.css";

export default function Header({ userName, avatarUrl }) {
    return (
        <div className="header-user">
            <span>Olá, {userName}</span>
            <img src={avatarUrl} alt="Avatar" className="avatar" />
        </div>
    );
}
