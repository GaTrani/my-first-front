import React from 'react';
import './Header.css';
import userProfile from '../../assets/profile-user.png'

function Header({ userName }) {
    return (
        <header>
            <div className="header-right">
                <div className="user-info">
                    <span className="greeting">Bem-vindo, {userName}</span>
                    <img
                        src={userProfile}
                        alt="User Profile"
                        className="profile-image"
                    />
                </div>
            </div>
        </header>
    );
}

export default Header;
