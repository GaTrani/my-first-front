import React from "react";
import { FaBars } from "react-icons/fa";

export default function HamburgerMenu() {
    return (
        <div>
            <FaBars size={20} style={{ color: "white" }} />
        </div>
    );
}
