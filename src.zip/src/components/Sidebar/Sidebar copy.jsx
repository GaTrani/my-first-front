import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Sidebar.css';

export default function Sidebar() {
    const [dropdown, setDropdown] = useState({
        client: false,
        supplier: false,
        finance: false,
    });

    const toggleDropdown = (menu) => {
        setDropdown({ ...dropdown, [menu]: !dropdown[menu] });
    };

    return (
        <div className="sidebar">
            <ul>
                <li><Link to="/home">Home</Link></li>
                <li>
                    <button onClick={() => toggleDropdown('client')}>Clientes</button>
                    {dropdown.client && (
                        <ul className="dropdown">
                            <li><Link to="/client">Listar Clientes</Link></li>
                            <li><Link to="/client/new">Novo Cliente</Link></li>
                        </ul>
                    )}
                </li>
                <li>
                    <button onClick={() => toggleDropdown('supplier')}>Fornecedores</button>
                    {dropdown.supplier && (
                        <ul className="dropdown">
                            <li>Listar Fornecedores</li>
                            <li>Novo Fornecedor</li>
                        </ul>
                    )}
                </li>
                <li>
                    <button onClick={() => toggleDropdown('finance')}>Financeiro</button>
                    {dropdown.finance && (
                        <ul className="dropdown">
                            <li>Entradas</li>
                            <li>Saídas</li>
                        </ul>
                    )}
                </li>
            </ul>
        </div>
    );
}

