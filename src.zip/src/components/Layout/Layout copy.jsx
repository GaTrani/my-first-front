import React, {useState } from 'react';
import './Layout.css'
import HamburgerMenu from '../Hamburger/HamburgerMenu'
import Header from "../../components/Header/Header";
import Sidebar from '../../components/Sidebar/Sidebar';

const Layout = ({ children }) => {
    const [sidebarVisible, setSidebarVisible] = useState(false); // Estado para controlar a visibilidade da sidebar

    const toggleSidebar = () => {
        setSidebarVisible(!sidebarVisible); // Alterna o estado da sidebar
    };
    return (
        <div className="layout">
            <div className="header">
                <div className="top-left"><HamburgerMenu/></div>
                <div className="top-right"><Header userName="João" /></div>
            </div>
            <div className="content">
                <div><Sidebar/></div> {/*  className="sidebar" */}
                <div className="content-main">{children}</div>
            </div>
        </div>
    )
}
export default Layout;