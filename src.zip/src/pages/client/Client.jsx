import React from "react";
import Layout from "../../components/Layout/Layout";

export default function Client(){
    return (
        <Layout>
            <div>
                <h2>Client</h2>
                <p>Page Client, app.</p>
            </div>
        </Layout>
    )
}