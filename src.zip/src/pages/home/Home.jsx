import React from "react";
import Layout from "../../components/Layout/Layout";

export default function Home(){
    return (
        <Layout>
            <div>
                <h2>HOME</h2>
                <p>Page home, app.</p>
            </div>
        </Layout>
    )
}