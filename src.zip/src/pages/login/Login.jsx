import React from "react";
import "./Login.css";

export default function Login() {
    return (
        <div className="login-container">
            <div className="card login-card shadow-lg">
                <div className="card-body">
                    <h1 className="card-title text-center mb-4">Bem-vindo!</h1>
                    <p className="text-muted text-center mb-4">
                        Faça login para acessar sua conta
                    </p>
                    <form>
                        {/* Campo de Email */}
                        <div className="mb-3">
                            <label htmlFor="email" className="form-label">
                                Email
                            </label>
                            <input
                                type="email"
                                className="form-control"
                                id="email"
                                placeholder="Digite seu email"
                                required
                            />
                        </div>

                        {/* Campo de Senha */}
                        <div className="mb-3">
                            <label htmlFor="password" className="form-label">
                                Senha
                            </label>
                            <input
                                type="password"
                                className="form-control"
                                id="password"
                                placeholder="Digite sua senha"
                                required
                            />
                        </div>

                        {/* Botão de Login */}
                        <button
                            type="submit"
                            className="btn btn-primary w-100 mt-3"
                        >
                            Entrar
                        </button>
                    </form>

                    {/* Links abaixo do formulário */}
                    <div className="text-center mt-4">
                        <a href="/register" className="text-decoration-none">
                            Não tem uma conta? <strong>Cadastre-se</strong>
                        </a>
                        <br />
                        <a href="/forgot-password" className="text-decoration-none">
                            Esqueceu sua senha?
                        </a>
                    </div>
                </div>
            </div>
        </div>
    );
}
